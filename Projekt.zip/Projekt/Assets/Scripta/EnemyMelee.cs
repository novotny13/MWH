using UnityEngine;

public class EnemyMelee : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float followDistance = 5f;
    public float distanceFromPlayer = 1f; // Vzd�lenost, ve kter� se nep��tel bude dr�et od hr��e

    Transform[] movePoints;
    private int currentMovePointIndex = 0;

    private Transform player;
    private Rigidbody2D rb;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        rb = GetComponent<Rigidbody2D>();

        Transform waypointsParent = GameObject.FindGameObjectWithTag("patrolPoints").transform;
        movePoints = new Transform[waypointsParent.childCount];

        // P�i�ad�me ka�d� bod do pole
        for (int i = 0; i < waypointsParent.childCount; i++)
        {
            movePoints[i] = waypointsParent.GetChild(i);
        }

        // Nastav�me pozici nep��tele na prvn� bod
    }
    private bool chace= false;
    void Update()
    {
        MoveBetweenPoints();

        // Pokud je hr�� v dosahu, nep��tel se pohne sm�rem k n�mu
        if (Vector2.Distance(transform.position, player.position) <= followDistance)
        {
          chace = true;
        }
        else
        {
            chace = false;
        }
        if(chace)
        {
            // Z�sk�me sm�r od nep��tele k hr��i
            Vector2 directionToPlayer = player.position - transform.position;
            // Normalizujeme sm�r a n�sob�me ho vzd�lenost� od hr��e, abychom se nep�ibl�ili p��li� bl�zko
            Vector2 moveDirection = directionToPlayer.normalized * (Vector2.Distance(player.position, transform.position) - distanceFromPlayer);
            // Pohybujeme se sm�rem k hr��i s respektov�n�m minim�ln� vzd�lenosti
            transform.Translate(moveDirection.normalized * moveSpeed * Time.deltaTime);
        }
        // Nastav�me rotaci nep��tele sm�rem k pohybu
        Vector2 movementDirection = rb.velocity.normalized;
        if (movementDirection != Vector2.zero)
        {
            float angle = Mathf.Atan2(movementDirection.y, movementDirection.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(new Vector3(0f, 0f, angle));
        }

        // Zkontrolujeme, zda nep��tel dos�hl posledn�ho bodu a p�epneme se na prvn� bod
        if (currentMovePointIndex == movePoints.Length)
        {
            currentMovePointIndex = 0;
        }
    }

    void MoveBetweenPoints()
    {
        // Pokud je nep��tel bl�zko aktu�ln�mu bodu, p�epneme se na dal�� bod
        if (Vector2.Distance(transform.position, movePoints[currentMovePointIndex].position) <= 0.1f)
        {
            currentMovePointIndex = (currentMovePointIndex + 1) % movePoints.Length;
        }

        // Pohybujeme se sm�rem k aktu�ln�mu bodu
        transform.position = Vector2.MoveTowards(transform.position, movePoints[currentMovePointIndex].position, moveSpeed * Time.deltaTime);
    }

    void MoveTowardsPlayer()
    {
        // Z�sk�me sm�r od nep��tele k hr��i
        Vector2 directionToPlayer = player.position - transform.position;
        // Normalizujeme sm�r a n�sob�me ho vzd�lenost� od hr��e, abychom se nep�ibl�ili p��li� bl�zko
        Vector2 moveDirection = directionToPlayer.normalized * (Vector2.Distance(player.position, transform.position) - distanceFromPlayer);
        // Pohybujeme se sm�rem k hr��i s respektov�n�m minim�ln� vzd�lenosti
        transform.Translate(moveDirection.normalized * moveSpeed * Time.deltaTime);
    }
}
