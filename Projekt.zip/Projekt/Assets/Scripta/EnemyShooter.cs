using UnityEngine;

public class EnemyShooter : MonoBehaviour
{
    public GameObject bulletPrefab; 
    public Transform firePoint; 
    public float shootInterval = 2f; 
    public float followDistance = 5f; 

     Transform[] movePoints; 
    public int currentMovePointIndex = 0; 

    public Transform player;
    public float shootTimer = 0f;

    public float moveSpeed = 5f;
    private Rigidbody2D rb;
    void Start()
    {

        player = GameObject.FindGameObjectWithTag("Player").transform;
        rb = GetComponent<Rigidbody2D>();

        Transform waypointsParent = GameObject.FindGameObjectWithTag("patrolPoints").transform;
        movePoints = new Transform[waypointsParent.childCount];

        // P�i�ad�me ka�d� bod do pole
        for (int i = 0; i < waypointsParent.childCount; i++)
        {
            movePoints[i] = waypointsParent.GetChild(i);
        }

        // Nastav�me pozici nep��tele na prvn� bod
    }

    void Update()
    {
        
        MoveBetweenPoints();

        
        if (IsPlayerInRange())
        {
            ShootAtPlayer();
        }

        
        if (IsPlayerTooClose())
        {
            MoveAwayFromPlayer();
        }
        Vector2 movementDirection = rb.velocity.normalized;
        if (movementDirection != Vector2.zero)
        {
            float angle = Mathf.Atan2(movementDirection.y, movementDirection.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(new Vector3(0f, 0f, angle));
        }
        if (currentMovePointIndex == movePoints.Length)
        {
            currentMovePointIndex = 0;
        }

    }

    bool IsPlayerInRange()
    {
        return Vector2.Distance(transform.position, player.position) <= GetCurrentMovePointRange();
    }

    bool IsPlayerTooClose()
    {
        return Vector2.Distance(transform.position, player.position) < followDistance;
    }

    float GetCurrentMovePointRange()
    {
        return Vector2.Distance(transform.position, movePoints[currentMovePointIndex].position);
    }

    void MoveBetweenPoints()
    {
        
        if (Vector2.Distance(transform.position, movePoints[currentMovePointIndex].position) <= 0.1f)
        {
            currentMovePointIndex = (currentMovePointIndex + 1) % movePoints.Length;
        }

    
        transform.position = Vector2.MoveTowards(transform.position, movePoints[currentMovePointIndex].position, moveSpeed * Time.deltaTime);
    }

    void ShootAtPlayer()
    {
     
        shootTimer += Time.deltaTime;

        
        if (shootTimer >= shootInterval)
        {
           
            Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
           
            shootTimer = 0f;
        }
    }

    void MoveAwayFromPlayer()
    {
        transform.position = Vector2.MoveTowards(transform.position, player.position, -0.5f * Time.deltaTime);
    }
}
