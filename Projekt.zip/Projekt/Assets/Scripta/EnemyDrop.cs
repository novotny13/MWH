using UnityEngine;

public class TestObject : MonoBehaviour
{
    public int dmg= 10; // Po�et zku�enost�, kter� p�id� hr��i
   bool kontakt = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Kontrola, zda objekt koliduje s hr��em
        if (other.CompareTag("Player"))
        {
            // Z�sk�n� referenc� na hr��sk� skript pro z�sk�n� zku�enost� a p�id�n� �rovn�
            PlayerStats playerStats = other.GetComponent<PlayerStats>();
            if (playerStats != null)
            {

                playerStats.TakeDamage(dmg);
                playerStats.GainExperience(50);  
                
            }

            // Zni�en� testovac�ho objektu
            
        }
    }
}
