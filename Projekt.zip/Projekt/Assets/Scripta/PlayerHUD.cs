using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHUD : MonoBehaviour
{
    public PlayerStats playerStats;
    public Shooting playerAmmo;
    public Slider healthSlider; 
    public Slider experienceSlider; 
    public Slider ammoSlider; 
    
    public Text levelText;

    void Update()
    {
       
        UpdateHealthUI();
        UpdateExperienceUI();

      UpdateAmmoUI();
        UpdateLevelText();
    }

    void UpdateHealthUI()
    {
        
        healthSlider.value = playerStats.health;
       
        healthSlider.maxValue = playerStats.maxHealth;
    }

    void UpdateExperienceUI()
    {
       
        experienceSlider.value = playerStats.experience;
       
         experienceSlider.maxValue = 100 + (playerStats.level *10);
    }
    void UpdateAmmoUI()
    {

        ammoSlider.value = playerAmmo.currentBullets;

        ammoSlider.maxValue = playerAmmo.maxBullets;
    }

    void UpdateLevelText()
    {
       
        levelText.text = "Level: " + playerStats.level.ToString();
    }
}
