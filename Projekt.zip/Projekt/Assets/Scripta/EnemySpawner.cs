using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab; 
    public float spawnInterval = 3f; 
    public int maxEnemies = 20; 
    private int currentEnemies = 0;
    private float timer = 0f; 

    void Update()
    {
        
        timer += Time.deltaTime;

       
        if (timer >= spawnInterval && currentEnemies < maxEnemies)
        {
            SpawnEnemy();
            timer = 0f;
        }
    }

    void SpawnEnemy()
    {
       
        Instantiate(enemyPrefab, transform.position, Quaternion.identity);
        currentEnemies++; 
    }
}
