using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    public int maxHealth = 100; // Maxim�ln� �ivoty nep��tele
    public int currentHealth;// Aktu�ln� �ivoty nep��tele
    public int experienceToAdd = 100; // Po�et zku�enost�, kter� p�id� hr��i po zni�en�
    public GameObject xpPrefab; // Prefab objektu XP
    public GameObject ammoPrefab; // Prefab objektu munice
    public float ammoSpawnChance = 0.2f; // Pravd�podobnost spawnut� munice (20%)
    public Slider healthSlider; // Reference na slider pro zobrazen� zdrav� nep��tele

    void Start()
    {
        currentHealth = maxHealth; // Nastav�me aktu�ln� �ivoty na maxim�ln� hodnotu p�i startu
        UpdateHealthUI(); // Aktualizujeme UI pro zdrav� nep��tele
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        UpdateHealthUI(); // Aktualizujeme UI pro zdrav� nep��tele

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        // Spawnujeme XP
        Instantiate(xpPrefab, transform.position, Quaternion.identity);

        // Podle �ance spawnujeme munici
        float randomValue = Random.value;
        if (randomValue <= ammoSpawnChance)
        {
            Instantiate(ammoPrefab, transform.position, Quaternion.identity);
        }

        // Zni��me nep��tele
        Destroy(gameObject);
    }

    void UpdateHealthUI()
    {
        if (healthSlider != null)
        {
            healthSlider.value = (float)currentHealth / maxHealth; // Aktualizujeme hodnotu slideru pro zdrav�
        }
    }
}
