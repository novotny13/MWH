using UnityEngine;

public class PlayerRotation : MonoBehaviour
{
    private Animator _animator;
    private float move;
   

    private void Awake()
    {
        _animator = GetComponent<Animator>();
    }

    void Update()
    {
       
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        
        Vector2 direction = mousePosition - transform.position;

        
        transform.up = direction;

        
        if (mousePosition.x > Screen.width / 2)
        {
            move = 1f;

            _animator.SetFloat("MoveX", move);
        }
        
        else
        {
            move = -1f;
        }
        Debug.Log(move);
    }
}
