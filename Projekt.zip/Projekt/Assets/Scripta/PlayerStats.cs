using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    public static PlayerStats instance; 
    public int level = 1;
    public int experience = 0;
    public float speed = 5f;
    public float maxSpeed = 10f;
    public int damage = 10;
    public int maxHealth = 100; 
    public int health = 100; 
/*
    void Awake()
    {
        if (instance == null)
        {
           
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            
            Destroy(gameObject);
        }
    }
*/
    public void LevelUp()
    {
        level++;
        experience -= 100 + (level * 10);

        Debug.Log("Player leveled up to level " + level);
    }

    public void IncreaseSpeed(float amount)
    {
        speed += amount;
        speed = Mathf.Clamp(speed, 0f, maxSpeed);
    }

    public void IncreaseDamage(int amount)
    {
        damage += amount;
    }

    public void GainExperience(int amount)
    {
        experience += amount;
        if (experience >= 100 + (level * 10))
        {
            LevelUp();
            IncreaseSpeed(5);
            Debug.Log("Speed: " + speed);
        }
    }

    public void IncreaseHealth(int amount)
    {
        health += amount;
        health = Mathf.Clamp(health, 0, maxHealth);
    }

    public void TakeDamage(int amount)
    {
        health -= amount;
        if (health <= 0)
        {
            Debug.Log("Player died!");
        }
    }
}
