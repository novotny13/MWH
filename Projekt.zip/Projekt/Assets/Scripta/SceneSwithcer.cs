using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwithcer : MonoBehaviour
{
   public void LoadSceneOne() {
        SceneManager.LoadScene("Planet1");

    }
    public void exit()
    {
        Application.Quit();
    }
    public void Death()
    {
        SceneManager.LoadScene("Death");
    }
    public void Menu()
    {
        SceneManager.LoadScene("Menu");
    }
}
