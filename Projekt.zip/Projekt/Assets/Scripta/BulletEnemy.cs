using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletEnemy : MonoBehaviour
{
    public float life = 5f;
    public int damage = 10;

    void Awake()
    {
        Destroy(gameObject, life);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Objekt"))
        {
            Destroy(gameObject);
        }
        else if (collision.gameObject.CompareTag("Enemy"))
        {
            PlayerStats Player = collision.gameObject.GetComponent<PlayerStats>();
            if (Player != null)
            {
                Player.TakeDamage(damage); //dodelat metodu pro TakeDamage
            }
            Destroy(gameObject);
        }
    }
}
