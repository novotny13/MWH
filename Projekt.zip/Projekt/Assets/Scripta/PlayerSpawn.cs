using UnityEngine;

public class PlayerSpawn : MonoBehaviour
{
    public GameObject playerPrefab; // Prefab hr��e
    public GameObject playerSpawnPoint; // Spawnpoint pro hr��e

    private void Start()
    {
        SpawnPlayer();
    }

    private void SpawnPlayer()
    {
        // Spawnout hr��e na spawnpointu
        GameObject player = Instantiate(playerPrefab, playerSpawnPoint.transform.position, Quaternion.identity);

        // P�ipojit hlavn� kameru hr��e
        Transform mainCamera = player.transform.Find("Main Camera");
        if (mainCamera != null)
        {
            mainCamera.GetComponent<Camera>().enabled = true;
            mainCamera.GetComponent<AudioListener>().enabled = true;
        }
        else
        {
            Debug.LogWarning("Main Camera not found as a child of the player object!");
        }
    }
}
