using System.Collections;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    public Transform bulletSpawnPoint;
    public GameObject bulletPrefab;
    public float bulletSpeed = 10;
    public int maxBullets = 10; // Maxim�ln� po�et n�boj�
    public int currentBullets; // Aktu�ln� po�et n�boj�
    public bool reloading = false; // Indikuje, zda prob�h� nab�jen�
    public float reloadTime = 2f; // Doba nab�jen� (v sekund�ch)

    void Start()
    {
        currentBullets = maxBullets; // Nastav�me aktu�ln� po�et n�boj� na maxim�ln� hodnotu p�i startu
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0) && currentBullets > 0 && !reloading)
        {
            ShootBullet();
        }
      

        if (Input.GetKeyDown(KeyCode.R) && currentBullets < maxBullets && !reloading)
        {
            StartCoroutine(Reload());
        }
        
    }

    void ShootBullet()
    {
        var bullet = Instantiate(bulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);
        bullet.GetComponent<Rigidbody2D>().velocity = bulletSpawnPoint.up * bulletSpeed;
        currentBullets--;
    }

    IEnumerator Reload()
    {
        reloading = true;
        yield return new WaitForSeconds(reloadTime);
        currentBullets = maxBullets;
        reloading = false;
    }
}
